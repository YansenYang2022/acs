/***********************************
Author by: Yansen Z Q Yang
Date: 2023 April , ACS Hackathon topic 7

Abstract:
     This is an exercise to use a tech of new trending named "NodeJs" to 
	 develop a typical RESTful API web service.
	 
*************************************/

//introducing express framework
var express = require('express');
var app = express();
var url = require("url");
var bodyParser  = require("body-parser");  

app.use(bodyParser.urlencoded({ extended: false })); 

 
 
/***************************************************************
RESTful API, action GET to retrieve all task,sort by id asc

invoked by:
curl http://your_server/suggestions

output: 
    All data in array JSON format.

*****************************************************************/ 

app.get('/suggestions',  function (req, res) {
    var pathname = url.parse(req.url).pathname;
    console.log("received request for " + pathname );
  	console.log("About to get all suggestion "  );
	
	 var result="This is all result";
	const fs = require("fs");
	const path = require("path");
	fs.readFile(path.join(__dirname,'suggestion_config.json'),'utf8',(err,data)=>{
		if (err){
			console.log(err)
			return
		}
		//console.log(data);
		
		let jsonObject =JSON.parse(data);   
		 
		let theSuggestions = [];
		Object.keys(jsonObject).forEach(resultKey=>{
			console.log("got result Key" + resultKey);
			theSuggestions.push(resultKey) ;
		});
		res.end( JSON.stringify(theSuggestions));	
	})
	   
})  
 
/***************************************************************
RESTful API, action GET to retrieve a suggestion by tag

param @id : (mandatory) type string, the record tag of the error case

invoked by:
curl http://your_server/suggestion/@id
 
output: 
    All matching data in array JSON format.

*****************************************************************/ 

app.get('/suggestion/:id',  function (req, res) {
    var pathname = url.parse(req.url).pathname;
    console.log("received request for " + pathname );
  	console.log("About to get  for " + req.params.id);
	const fs = require("fs");
	const path = require("path");
	fs.readFile(path.join(__dirname,'suggestion_config.json'),'utf8',(err,data)=>{
		if (err){
			console.log(err)
			return
		}
		//console.log(data);
		let arr=JSON.parse(data);  
		let theSuggestion=[];		
		if (!arr[req.params.id])
			theSuggestion=[];
		else
			theSuggestion = arr[req.params.id]
	
		res.end( JSON.stringify(theSuggestion));
			
	})
	   

  
}) 
 

/***********************************************************
RESTful API, action DELETE to delete a suggestion by tagId

param @id : (mandatory)type integer, the id of the task. Must be an existing task id

invoked by:
curl -X DELETE http://your_server/suggestion/@id

called by sample: 
curl -X DELETE http://111.231.31.105/suggestion/@db_case_1
*************************************************************/ 

app.delete('/suggestion/:id',  function (req, res) {
    var pathname = url.parse(req.url).pathname;
    console.log("received delete request for " + pathname );
  	console.log("About to delete for " + req.params.id);
 
	const fs = require("fs");
	const path = require("path");
	var returnResult="";
	fs.readFile(path.join(__dirname,'suggestion_config.json'),'utf8',(err,data)=>{
		if (err){
			console.log(err)
			return
		}
		//console.log(data);
		let arr=JSON.parse(data);  
		if (!arr[req.params.id]){
			returnResult="Not found such tag: "+req.params.id;
			res.end( JSON.stringify("Delete failed:"+returnResult));
			return
		}
			
		else
			delete arr[req.params.id];
		
		let newArrJson = JSON.stringify(arr);
		console.log("Try to save json:"+newArrJson)
		fs.writeFile(path.join(__dirname,'suggestion_config.json'),newArrJson,'utf8',(err)=>{
			console.log("Write done",err);
		});
	})
	    res.end( JSON.stringify("Delete Done"));

})

/***************************************************************
RESTful API, action post to add new suggestion data

param @tag : (mandatory)type string 
param @suggestion : (mandatory)type string 
param @contact_point : (mandatory)type string 

invoked by:
curl -X POST -d "tag=@gateway_case_1&suggestion=@pls check if the papi gateway policy&contact_point=Papi ACS" http://your_server/suggestion
 

output: 
      Message of result.
*****************************************************************/ 

app.post('/suggestion', function (req, res) {
  var pathname = url.parse(req.url).pathname;
    console.log("received post request for " + pathname + JSON.stringify(req.body) );
	//check if mandatory fields are valid
	if(typeof(req.body.tag)=='undefined'){
		msg="input tag invalid, please check tag";
		console.log(msg);
	    res.end( msg);
		return;
	}
	
	if(typeof(req.body.suggestion)=='undefined'){
		msg="input suggestion invalid, please check suggestion";
		console.log(msg);
	    res.end( msg);
		return;
	}
	
	if(typeof(req.body.contact_point)=='undefined'){
		msg="input contact_point invalid, please check contact_point";
		console.log(msg);
	    res.end( msg);
		return;
	}
	
	const fs = require("fs");
	const path = require("path");
	fs.readFile(path.join(__dirname,'suggestion_config.json'),'utf8',(err,data)=>{
		if (err){
			console.log(err)
			return
		}
		//console.log(data);
		let arr=JSON.parse(data);  
		arr[req.body.tag]={"suggestion":req.body.suggestion , "contact_point":req.body.contact_point};
		let newArrJson = JSON.stringify(arr);
		console.log("Try to save json:"+newArrJson)
		fs.writeFile(path.join(__dirname,'suggestion_config.json'),newArrJson,'utf8',(err)=>{
			console.log("Write done",err);
		});
	})
	    res.end( JSON.stringify("Done"));
})
 

// function to write operation log, remark is the after image of title
function writeLog(taskId,operationType,operator,remark) {
	console.log("Write Log for operation ["+ operationType + "] on id " + taskId);
	 
	
}


/***********************************************************
API, stop server ,Graceful shutdown, close db connections

invoked by:
curl http://your_server/shutdown

called by sample: 
curl http://111.231.31.105/shutdown

*************************************************************/ 
 
app.get('/shutdown', function (req, res) {
  
  console.log("About to close db connection before exit"  );
 
  console.log( "Graceful shutdown, Bye" );
  res.end( "Graceful shutdown, Bye");
  process.exit(0);  
})

var server = app.listen(80, function () {

  var host = server.address().address
  var port = server.address().port
  console.log("RESTful API Server Started" )

})